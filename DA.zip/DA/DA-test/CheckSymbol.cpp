//
// Created by 王志星 on 2022/9/23.
//

#include "CheckSymbol.h"

bool CheckSymbol(std::unordered_map<std::string, SymbolTable *> Filemap,
                 std::unordered_map<clang::FileID, SymbolTable *, FileIDHash> FileIDMap,
                 std::string Filename,
                 std::string Symbolname,
                 SymbolType Symboltype){
  // Filename是否有symboltable表。
  std::unordered_map<std::string, SymbolTable *>::iterator FileSymbolTableIter = Filemap.find(Filename);
  if (FileSymbolTableIter != Filemap.end() ){
    SymbolTable *FileSymbolTable = FileSymbolTableIter->second;
    std::vector<Symbol *> Symboltable = FileSymbolTable->getSymbolTable();
    for (Symbol *symbol : Symboltable) {
      if(symbol->name==Symbolname&&symbol->st == Symboltype){
        return true;
      }
    }
  }
  return false;
}