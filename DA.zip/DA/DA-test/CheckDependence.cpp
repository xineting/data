/*************************************************
 * The entry of DA program, only extract one     *
 * source file's information.                    *
 *                                               *
 * HISTORY:                                      *
 *	06/22/2020 pyx : Created.                *
 *	06/01/2022 pyx : Edited.                 *
=================================================*/
#include "CheckDependence.h"
#include "../DAASTFrontedAction.h"
#include "../Util.h"
#include "clang/Driver/Job.h"
#include "clang/Tooling/Tooling.h"
#include "llvm/Support/CommandLine.h"
#include <vector>

SymbolTable *getFileSymbolTable(
    clang::FileID Fid,
    std::unordered_map<clang::FileID, SymbolTable *, FileIDHash> FileIDMap) {
  std::unordered_map<clang::FileID, SymbolTable *, FileIDHash>::iterator Iter =
      FileIDMap.find(Fid);
  if (Iter != FileIDMap.end())
    return Iter->second;
  return nullptr;
}

std::string getFilePath(
    clang::FileID Fid,
    std::unordered_map<clang::FileID, SymbolTable *, FileIDHash> FileIDMap) {
  SymbolTable *st = getFileSymbolTable(Fid, FileIDMap);
  return st->getSymbolTableFilePath();
}

bool CheckDependence(
    std::unordered_map<std::string, SymbolTable *> Filemap,
    std::unordered_map<clang::FileID, SymbolTable *, FileIDHash> FileIDMap,
    std::string Sourcefilepath, std::string Targetfilepath,
    std::string Sourcename, std::string Targetname,
    SDependencyType Sdependencytype) {
  // 找到我们的依赖关系是否存在
  // Sourcefilepath是否有symboltable表。
  std::unordered_map<std::string, SymbolTable *>::iterator Itersource =
      Filemap.find(Sourcefilepath);
  std::unordered_map<std::string, SymbolTable *>::iterator Itertarget =
      Filemap.find(Targetfilepath);
  if (Itersource != Filemap.end() && Itertarget != Filemap.end()) {
    SymbolTable *Symboltablesource = Itersource->second;
    SymbolTable *Symboltabletarget = Itertarget->second;
    std::vector<SDependency *> SDependencyvector =
        Symboltablesource->getSymbolDependency();
    for (SDependency *Sdependency : SDependencyvector) {
      // 检查每一个依赖关系是否对应到我们的特定的查找的关系。
      std::string Efidname = getFilePath(Sdependency->efid, FileIDMap);
      if (Efidname == Targetfilepath) {
        Symbol *St = Symboltablesource->getSymbol(Sdependency->ssid);
        std::string Ssymbolname = St->name;
        Symbol *Et = Symboltabletarget->getSymbol(Sdependency->esid);
        std::string Esymbolname = Et->name;
        if (Sdependency->sdt == Sdependencytype && Efidname == Targetfilepath &&
            Ssymbolname == Sourcename && Esymbolname == Targetname) {
          return true;
        }
      }
    }
  }
  return false;
}
