//
// Created by 王志星 on 2022/9/23.
//

#ifndef LLVM_CHECKSYMBOL_H
#define LLVM_CHECKSYMBOL_H


#include "../DAASTFrontedAction.h"
#include "../Util.h"
#include "clang/Driver/Job.h"
#include "clang/Tooling/Tooling.h"
#include "llvm/Support/CommandLine.h"
#include <vector>

bool CheckSymbol(std::unordered_map<std::string, SymbolTable *> Filemap,
                 std::unordered_map<clang::FileID, SymbolTable *, FileIDHash> FileIDMap,
                 std::string Filename,
                 std::string Symbolname,
                 SymbolType Symboltype);

#endif // LLVM_CHECKSYMBOL_H
