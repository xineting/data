//
// Created by 王志星 on 2022/9/23.
//

#include "CheckReference.h"

bool CheckReference(
    std::unordered_map<std::string, SymbolTable *> Filemap,
    std::unordered_map<clang::FileID, SymbolTable *, FileIDHash> FileIDMap,
    std::string Filename, std::string Symbolname, RefType refType) {
  std::unordered_map<std::string, SymbolTable *>::iterator FileSymbolTableIter = Filemap.find(Filename);
  SymbolTable *FileSymbolTable = FileSymbolTableIter->second;
  if (FileSymbolTableIter != Filemap.end()) {
    std::vector<Ref *> Reftable;
    if (refType == RT_Definition) {
      Reftable= FileSymbolTable->getglobalDefTable();
    } else if (refType == RT_Declaration) {
      Reftable = FileSymbolTable->getglobalDecTable();
    } else {
      Reftable = FileSymbolTable->getrefTable();
    }
    // 拿到rettable表之后，查看这个表中每个sid，
    // 看他们的reftype是否和需要差的reftype一样，然后查看是否在sid中
    for(Ref* ref:Reftable){
      if(ref->rt == refType){
        Symbol *St = FileSymbolTable->getSymbol(ref->sid);
        if(St->name == Symbolname){
          return true;
        }
      }
    }
  }
  return false;
}