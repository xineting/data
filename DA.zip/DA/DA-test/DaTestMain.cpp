//
// Created by 王志星 on 2022/9/20.
//

#include "gtest/gtest.h"
#include "iostream"

std::string workdirectory;
//"/Users/wzx/Downloads/llvm-git/clang-tools-extra/DA/DA-test/TestCode";

int main(int argc, char **argv) {
  if(argc==2){
    workdirectory  = argv[1];
  }
  else{
    workdirectory  = getenv("TestCode");
    std::cout<<workdirectory<<'\n';
  }


  testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}
