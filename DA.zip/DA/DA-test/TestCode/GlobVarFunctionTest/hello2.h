int globinhello2 = 1;
typedef struct {
    int a;
    int b;
} structtypedef;
structtypedef structtypedefdecl;
enum {
    enumuator1,
    enumuator2
};