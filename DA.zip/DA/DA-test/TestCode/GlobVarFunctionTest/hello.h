#include "hello2.h"

int externglob1 = 1;
int globinhello_h = 1;
void test(){
    globinhello2+=1;
}