#include "hello.h"
int sourceinmain_c;
enum EnumDef EnumTarget;
typedefname typedefTarget;

int sourceinmain_c2;
int functionreturn1(){
    return 1;
}

int paraminmain = 1;

int functionreturn2(int param2){
    return 2;
}

int int_add(int a,int b){
    return a+b;
}
int int_sub(int a,int b){
    return a-b;
}

int (*int_operator)(int,int);
int main(){
    test();
    //BinaryTest1
    sourceinmain_c = targetinhello_h+targetinhello2_h;
    //BinaryTest2
    EnumSource = EnumTarget;
    //BinaryTest3
    typedefTarget = typedefSource;
    //BinaryTest4
    typedefTarget = Enumuator_1;
    //test5判断语句中夹杂着别的东西的话，能否看到依赖关系。
    sourceinmain_c2 = Enumuator_1+targetinhello_h+targetinhello2_h +functionreturn1()+functionreturn2(paraminmain);
    //test6函数指针的依赖
    int_operator = int_add;
}
