#include "hello2.h"

int targetinhello_h = 0;
int sourceinhello_h ;

enum EnumDef{
  Enumuator_1,
  Enumuator_2
};

typedef int typedefname;


enum EnumDef EnumSource;



typedefname typedefSource;
void test(){
    sourceinhello_h = targetinhello2_h;
}