#include "hello.h"

int main(){
    int (*pAddFuncVar)(int, int);
    pAddFuncVar = int_add;
    functioninhello3(pAddFuncVar);
    return 1;
}
