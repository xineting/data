//
// Created by 王志星 on 2022/9/22.
//

#ifndef TESTCODE_HELLO_H
#define TESTCODE_HELLO_H

#define DefineNameInHello int a = 1;


#endif //TESTCODE_HELLO_H
