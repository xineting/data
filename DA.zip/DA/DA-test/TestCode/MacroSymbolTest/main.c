#include "hello.h"

#define DefineName1 1 //RT_Definition
#define DefineName2 2 //RT_Definition

#ifndef DefineNameInHello //RT_DefinedTest
#define DefineNameInHello3 int c = 1; //找不到
#endif

#ifdef DefineNameInHello //RT_DefinedTest
#define DefineNameInHello4 int c = 1; //ST_Macro //RT_RT_Definition
#endif

#define DefineNameInHello5 int tmp; //RT_Definition
#undef DefineNameInHello5           //RT_Undefinition

int main(){
    DefineNameInHello //RT_Expansion
    return 1;
}
