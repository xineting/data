int targetfunctioninhello2h(){
    return 1;
}
void targetfunctioninhello2h2(){

}