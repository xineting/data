//
// Created by 王志星 on 2022/9/22.
//

#ifndef TESTCODE_HELLO_H
#define TESTCODE_HELLO_H

#include "hello2.h"
#endif //TESTCODE_HELLO_H
