#include "stdio.h"
#include "hello.h"
#include "hello2.h"

int main(){
    return 1;
}