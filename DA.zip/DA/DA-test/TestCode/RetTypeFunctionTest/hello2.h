typedef struct structname{
    int a;
    int b;
}typedefname;