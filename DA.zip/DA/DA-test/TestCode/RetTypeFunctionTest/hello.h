#include "hello2.h"
#include "stdio.h"

typedef struct structname2{
    int a;
    int b;
}typedefname2;

typedefname functioninhello1();

typedefname2 functioninhello2();

typedefname2 functioninhello3(){
    typedefname2 tmp;
    tmp.b = 1;
    tmp.a = 2;
    return tmp;
}

typedefname2* functioninhello4(){
    return NULL;
}

