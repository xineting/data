#include "hello.h"

int main(){
    int *a = NULL;
}
