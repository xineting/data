typedef struct{
    int a;
    int b;
}typedefname1;

typedef struct structname1{
    int a;
    int b;
}typedefname2;

struct structname2{
    int a;
    int b;
};

typedef struct structname2 typedefname3;

int main(){

}


