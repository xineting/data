typedef struct {
    int a;
    int b;
}targettypedef1;


typedef union targetunion1 {
    int a;
    int b;
}targettypedef2;

struct targetstruct1 {
    int a;
    int b;
};

union targetunion2 {
    int a;
    int b;
};

typedef int targettypedef3;

typedef targettypedef3 targettypedef4;

