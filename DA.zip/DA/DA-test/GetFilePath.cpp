//
// Created by 王志星 on 2022/9/23.
//

#include "GetFilePath.h"


//
// Created by 王志星 on 2022/9/23.
//

#include "GetFilePath.h"

SymbolTable *getFileSymbolTable(
    clang::FileID Fid,
    std::unordered_map<clang::FileID, SymbolTable *, FileIDHash> FileIDMap) {
  std::unordered_map<clang::FileID, SymbolTable *, FileIDHash>::iterator Iter =
      FileIDMap.find(Fid);
  if (Iter != FileIDMap.end())
    return Iter->second;
  return nullptr;
}

std::string getFilePath(
    clang::FileID Fid,
    std::unordered_map<clang::FileID, SymbolTable *, FileIDHash> FileIDMap) {
  SymbolTable *st = getFileSymbolTable(Fid, FileIDMap);
  return st->getSymbolTableFilePath();
}
