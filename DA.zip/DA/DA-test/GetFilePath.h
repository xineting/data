//
// Created by 王志星 on 2022/9/23.
//

#ifndef LLVM_GETFILEPATH_H
#define LLVM_GETFILEPATH_H

#include "../DAASTFrontedAction.h"
#include "../Util.h"

SymbolTable *getFileSymbolTable(
    clang::FileID Fid,
    std::unordered_map<clang::FileID, SymbolTable *, FileIDHash> FileIDMap);

std::string getFilePath(
    clang::FileID Fid,
    std::unordered_map<clang::FileID, SymbolTable *, FileIDHash> FileIDMap);

#endif // LLVM_GETFILEPATH_H
