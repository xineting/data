#include "hello.h"

typedef struct sourcestruct1 {
    targettypedef1 Field1;
    targettypedef2 Field2;
    struct targetstruct1 Field3;
    union targetunion2 Field4;
    targettypedef4 Field5;
} sourcetypedef1;


typedef union sourceunion1 {
    targettypedef1 Field1;
    targettypedef2 Field2;
    struct targetstruct1 Field3;
    union targetunion2 Field4;
} sourcetypedef2;


struct sourcestruct2 {
    targettypedef1 Field1;
    targettypedef2 Field2;
    struct targetstruct1 Field3;
    union targetunion2 Field4;
};

union sourceunion2 {
    targettypedef1 Field1;
    targettypedef2 Field2;
    struct targetstruct1 Field3;
    union targetunion2 Field4;
};

int main() {
    return 1;
}
