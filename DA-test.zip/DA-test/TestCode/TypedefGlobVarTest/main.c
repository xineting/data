#include "hello.h"

typdefenum enumglob;

enum enumdef enumglob2;

typedef1 typedef1glob;

typedef2 typedef2glob;

typedef3 typedef3glob;

struct struct2 struct2glob;

int main(){

    return 1;
}
