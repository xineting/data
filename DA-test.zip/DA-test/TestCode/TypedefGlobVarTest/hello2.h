typedef int typedef1;

typedef struct{
    int a;
    int b;
}typedef2;

typedef struct struct2 {
    int a;
    int b;
}typedef3;

typedef enum enumdef{
    Enumuator1,
    Enumuator2,
}typdefenum;


typedef enum{
    Enumuator3,
    Enumuator4,
}typdefenum2;