#include "hello2.h"

int globinhello_h = 1;
void test(){
    globinhello2+=1;
}