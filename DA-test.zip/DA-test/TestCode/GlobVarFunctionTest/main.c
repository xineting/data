#include "hello.h"
int sourceinmain_c;
int globinmain = 1;

int main(){
    test();
    int noglob1 = enumuator2+globinhello_h;
    int noglob2 = globinmain;
    structtypedefdecl.b = 1;
    return 1;
}
