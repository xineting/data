#include "hello.h"
int sourceinmain_c;
enum EnumDef EnumTarget;
typedefname typedefTarget;

int main(){
    test();

    //BinaryTest1
    sourceinmain_c = targetinhello_h+targetinhello2_h;
    //BinaryTest2
    EnumSource = EnumTarget;
    //BinaryTest3
    typedefTarget = typedefSource;

    //BinaryTest4
    typedefTarget = Enumuator_1;

    //test5
    sourceinmain_c = Enumuator_1+targetinhello_h+targetinhello2_h;


    return 1;
}
