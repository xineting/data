#include "hello2.h"

typedef struct structname2{
    int a;
    int b;
}typedefname2;

void functioninhello1(typedefname*,typedefname2 param2);

void functioninhello2(typedefname* param1,typedefname2 param2){

}

