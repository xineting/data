#include "hello.h"


int main(){
    int tmp =1+targetfunctioninhello1();
    targetfunctioninhello2h2();
    return 1;
}
