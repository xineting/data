#include "hello2.h"
int targetfunctioninhello1(){
    int tmp = targetfunctioninhello2h();
    targetfunctioninhello2h2();
    return 1;
}