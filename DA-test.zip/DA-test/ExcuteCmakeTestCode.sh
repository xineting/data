#!/bin/bash

if [ -z "$1" ]
  then
    CUR_FOLDER=$(dirname $(readlink -f "$0"))
    TESTCODE_FOLDER=${CUR_FOLDER}"/TestCode/" 
else
  TESTCODE_FOLDER=$1
fi

echo ${TESTCODE_FOLDER}
cd ${TESTCODE_FOLDER}

function foo() {
   typeset -a arr=("$@")
   for e in "${arr[@]}"; do
      if [ -d $e ];then
          cd $e
          if [ -d "build"  ];then
            rm -rf "build"
            mkdir "build"
            cd "build"
          fi
          cmake .. -DCMAKE_EXPORT_COMPILE_COMMANDS=1
          cd ../../
      else
          echo "error"
      fi
    done
} 

array=(FieldTypeTagTest FunctionFunctionTest GlobVarFunctionTest GlobVarGlobVarTest ParamTypeFunctionTest "RetTypeFunctionTest" "TagTypedefTEST" "TypedefGlobVarTest")
foo "${array[@]}"
