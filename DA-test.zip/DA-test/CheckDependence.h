/*************************************************
 * The entry of DA program, only extract one     *
 * source file's information.                    *
 *                                               *
 * HISTORY:                                      *
 *	06/22/2020 pyx : Created.                    *
 *	06/01/2022 pyx : Edited.                     *
=================================================*/

#ifndef CHECK_DEPENDENCE_H
#define CHECK_DEPENDENCE_H

#include "../DAASTFrontedAction.h"
#include "../Util.h"
#include "clang/Driver/Job.h"
#include "clang/Tooling/Tooling.h"
#include "llvm/Support/CommandLine.h"
#include <vector>


SymbolTable *getFileSymbolTable(clang::FileID Fid,std::unordered_map<clang::FileID, SymbolTable *, FileIDHash> FileIDMap);

std::string getFilePath(clang::FileID Fid,std::unordered_map<clang::FileID, SymbolTable *, FileIDHash> FileIDMap) ;
bool CheckDependence(std::unordered_map<std::string, SymbolTable *> Filemap,
                     std::unordered_map<clang::FileID, SymbolTable *, FileIDHash> FileIDMap,
                     std::string Sourcefilepath,
                     std::string Targetfilepath,
                     std::string Sourcename,
                     std::string Targetname,
                     SDependencyType Sdependencytype);

#endif // CHECK_DEPENDENCE_H